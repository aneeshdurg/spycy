from . import pypher
pypher.main()
